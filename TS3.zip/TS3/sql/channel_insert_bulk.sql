insert into channels (server_id, channel_parent_id, org_channel_id ) VALUES (:server_id:, :parent_id*:, :org_channel_id*:)[[[,(:server_id:, :parent_id*:, :org_channel_id*:)]]];

